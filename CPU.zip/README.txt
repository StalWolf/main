ENGLISH INSTRUCTIONS:
Since the application does not have a button to close the application, follow the instructions below to close it.
-In the taskbar, right-click on the application's icon and select "close all windows". The application will be closed. 
IF IT DOESN'T WORK: open the task manager by pressing ctrl+shift+escap simultaneously, right-click on the line "html application host", then click on "end task".

INSTRUCTIONS EN FRANCAIS:
Etant donné que l'application de possède pas de bouton permettant de fermer l'application, suivez les instructions suivantes pour la fermer.
-dans la barre des tâches, faites clique-droit sur l'icône de l'application, puis sélectionnez "fermez toutes les fenêtres". L'application sera fermée. 
SI CELA NE FONCTIONNE PAS: ouvrez le gestionnaire des tâches en appuyant simultanément sur ctrl+shift+escap, faites clique droit sur la ligne "hôte des applications html", puis cliquez sur "fin de tâche"